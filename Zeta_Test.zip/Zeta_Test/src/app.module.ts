import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import appConfigurations from './config/app.configuration';
import mongoConfiguration from './config/mongo.configuration';
import awsConfiguration from './config/aws.configuration';
import mailConfiguration from './config/mail.configuration';

@Module({
  imports: [
    ConfigModule.forRoot({
      load: [
        appConfigurations,
        mongoConfiguration,
        awsConfiguration,
        mailConfiguration,
      ],
      isGlobal: false,
    }),
  ],
  controllers: [AppController],
  providers: [AppService],
  exports: [],
})
export class AppModule {}
