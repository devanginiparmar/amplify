import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class AppService {
  constructor(config: ConfigService) {
    console.log('Test', config.get('app.port'));
  }
  getHello(): string {
    return 'Sumit#';
  }
}
